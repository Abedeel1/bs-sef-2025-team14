from django import forms
from django.contrib.auth.forms import AuthenticationForm
from django.core.exceptions import ValidationError

class EmailLoginForm(AuthenticationForm):
    username = forms.CharField(widget=forms.TextInput(attrs={
        'class': 'form-input', 
        'placeholder': 'user@ac.sce.ac.il'
    }))
    password = forms.CharField(widget=forms.PasswordInput(attrs={
        'class': 'form-input', 
        'placeholder': 'Enter your password',
        'id': 'password-field'
    }))

    def clean_username(self):
        username = self.cleaned_data.get('username')
        if not username.endswith('@ac.sce.ac.il'):
             raise ValidationError("Access restricted to institutional emails (@ac.sce.ac.il) only.")
        return username