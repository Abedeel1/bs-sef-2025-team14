from django.shortcuts import render, redirect
from django.contrib.auth import login, logout
from django.contrib.auth.decorators import login_required
from .forms import EmailLoginForm

def login_view(request):
    if request.user.is_authenticated:
        if request.user.role == 'JUDGE':
            return redirect('judge_dashboard')
        elif request.user.role == 'ORGANIZER':
            return redirect('organizer_dashboard')
        else:
            return redirect('student_results')

    if request.method == 'POST':
        form = EmailLoginForm(data=request.POST)
        if form.is_valid():
            user = form.get_user()
            login(request, user)
            if user.role == 'JUDGE':
                return redirect('judge_dashboard')
            elif user.role == 'ORGANIZER':
                return redirect('organizer_dashboard')
            else:
                return redirect('student_results')
    else:
        form = EmailLoginForm()

    return render(request, 'login.html', {'form': form})


@login_required
def organizer_dashboard(request):
    return render(request, 'organizer_dashboard.html')

@login_required
def judge_dashboard(request):
    return render(request, 'judge_dashboard.html')

@login_required
def student_dashboard(request):
    return render(request, 'student_results.html')