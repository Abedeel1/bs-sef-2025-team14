from django.db import models
from django.contrib.auth.models import AbstractUser

class User(AbstractUser):
    ROLE_CHOICES = (
        ('ORGANIZER', 'Organizer'),
        ('JUDGE', 'Judge'),
        ('STUDENT', 'Student'),
    )
    role = models.CharField(max_length=10, choices=ROLE_CHOICES, default='STUDENT')
    
    groups = models.ManyToManyField(
        'auth.Group', 
        related_name='core_user_groups', 
        blank=True
    )
    user_permissions = models.ManyToManyField(
        'auth.Permission', 
        related_name='core_user_permissions', 
        blank=True
    )

class Evaluation(models.Model):
    date = models.DateTimeField(auto_now_add=True)
    judge_name = models.CharField(max_length=100)
    showcase_name = models.CharField(max_length=200)
    
    creativity = models.IntegerField()
    technical = models.IntegerField()
    presentation = models.IntegerField()
    impact = models.IntegerField()
    execution = models.IntegerField()
    comments = models.TextField(blank=True, null=True)

    @property
    def total_score(self):
        return self.creativity + self.technical + self.presentation + self.impact + self.execution

    def __str__(self):
        return self.showcase_name