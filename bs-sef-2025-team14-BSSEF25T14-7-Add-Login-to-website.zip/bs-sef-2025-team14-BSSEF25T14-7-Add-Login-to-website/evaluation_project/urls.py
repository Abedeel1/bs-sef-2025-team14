from django.contrib import admin
from django.urls import path
from django.contrib.auth.views import LogoutView 
from core import views 

urlpatterns = [
    path('admin/', admin.site.urls),
    
    path('', views.login_view, name='login'),
    
    path('organizer/dashboard/', views.organizer_dashboard, name='organizer_dashboard'),
    path('judge/dashboard/', views.judge_dashboard, name='judge_dashboard'),
    path('student/results/', views.student_dashboard, name='student_results'),

    path('logout/', LogoutView.as_view(next_page='login'), name='logout'),
]